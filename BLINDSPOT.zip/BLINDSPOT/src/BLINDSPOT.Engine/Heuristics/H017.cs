namespace BLINDSPOT.Engine.Heuristics; public static class H017 { public static double Score(double a,double b,double c)=> (0.5*a+0.3*b+0.2*c)/(1.0+System.Math.Abs(a-b)*0.01); }
