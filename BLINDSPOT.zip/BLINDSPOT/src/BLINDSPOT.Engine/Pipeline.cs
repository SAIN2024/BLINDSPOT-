using System.Text.Json;
using BLINDSPOT.Core;

namespace BLINDSPOT.Engine;

public static class Io {
    public static readonly JsonSerializerOptions J = new(){WriteIndented=true, PropertyNamingPolicy=JsonNamingPolicy.CamelCase};
}

public sealed class StaticExtractor {
    private sealed class Model { public List<Node> Rules {get;set;}=new(); }
    private sealed class Node { public string Id{get;set;}=""; public string Variable{get;set;}=""; public double? Min{get;set;} public double? Max{get;set;} public double? MaxRate{get;set;} }
    private static List<Node> Load(string p)=> JsonSerializer.Deserialize<Model>(File.ReadAllText(p), Io.J)?.Rules ?? new();

    public IReadOnlyList<Constraint> Extract(string plc, string esd, string op){
        var outp = new List<Constraint>();
        outp.AddRange(Load(plc).Select(x=> new Constraint(x.Id,x.Variable,Layer.Control, x.MaxRate is null ? (x.Min is null? CType.UpperBound:CType.LowerBound):CType.RateLimit, x.Min,x.Max,x.MaxRate)));
        outp.AddRange(Load(esd).Select(x=> new Constraint(x.Id,x.Variable,Layer.Safety, x.MaxRate is null ? (x.Min is null? CType.UpperBound:CType.LowerBound):CType.RateLimit, x.Min,x.Max,x.MaxRate)));
        outp.AddRange(Load(op).Select(x=> new Constraint(x.Id,x.Variable,Layer.Operator, x.MaxRate is null ? (x.Min is null? CType.UpperBound:CType.LowerBound):CType.RateLimit, x.Min,x.Max,x.MaxRate)));
        return outp;
    }
}

public sealed class TraceEngine {
    public IReadOnlyList<Point> LoadCsv(string path){
        var lines=File.ReadAllLines(path); var h=lines[0].Split(','); var vars=h.Skip(1).Where(x=>x!="alarm").ToArray();
        var pts=new List<Point>();
        for(int i=1;i<lines.Length;i++){
            var s=lines[i].Split(','); int t=int.Parse(s[0]); var d=new Dictionary<string,double>();
            for(int j=0;j<vars.Length;j++) d[vars[j]]=double.Parse(s[j+1]);
            var a = Enum.TryParse<Alarm>(s[^1], true, out var ax)? ax: Alarm.None;
            pts.Add(new Point(t,d,a));
        }
        return pts;
    }
    public IReadOnlyList<Window> Partition(IReadOnlyList<Point> trace, int seg){
        var w=new List<Window>(); if(trace.Count==0) return w;
        int i=0, st=trace[0].T;
        while(i<trace.Count){ int en=st+seg-1; var p=new List<Point>(); while(i<trace.Count && trace[i].T<=en){p.Add(trace[i]); i++;} if(p.Count==0) break; w.Add(new Window(st,p[^1].T,p)); st=en+1; }
        return w;
    }
    public IReadOnlyList<Slack> Slack(IReadOnlyList<Window> ws, IReadOnlyList<Constraint> cs){
        var s=new List<Slack>();
        foreach(var w in ws) foreach(var p in w.Points) foreach(var c in cs){
            if(!p.V.TryGetValue(c.Variable, out var v)) continue;
            double val = c.Max is double mx ? (mx-v) : (c.Min is double mn ? (v-mn) : 0);
            s.Add(new Slack(p.T,c.Id,val));
        }
        return s;
    }
    public IReadOnlyList<Pattern> Patterns(IReadOnlyList<Constraint> cs, IReadOnlyList<Slack> s){
        var list = new List<Pattern>();
        foreach(var c in cs){
            var x=s.Where(z=>z.ConstraintId==c.Id).OrderBy(z=>z.T).ToList();
            if(x.Count<2){ list.Add(new Pattern(c.Id,0,double.PositiveInfinity,0)); continue; }
            double min=x.Min(v=>v.Value); double neg=0; int n=0; double rec=0;
            for(int i=1;i<x.Count;i++){ double d=x[i].Value-x[i-1].Value; if(d<0){neg+=-d; n++;} if(d>rec) rec=d; }
            double slope=n==0?0:neg/n; double ttc=slope<=1e-9?double.PositiveInfinity:Math.Max(0,x[^1].Value)/slope;
            list.Add(new Pattern(c.Id,min,ttc,rec));
        }
        return list;
    }
}

public sealed class Generator {
    public IReadOnlyList<Template> Generate(IReadOnlyList<Constraint> cs, Config cfg){
        var rng=new Random(cfg.Seed); var vars=cs.Select(c=>c.Variable).Distinct().ToList();
        var outp=new List<Template>(); int n=Math.Min(cfg.MaxTemplates, Math.Max(80, vars.Count*30));
        for(int i=0;i<n;i++){
            int k=rng.Next(1, Math.Min(6, vars.Count+1)); var acts=new List<ActionStep>();
            for(int j=0;j<k;j++){ var v=vars[rng.Next(vars.Count)]; int st=rng.Next(0,cfg.Horizon/2); int en=Math.Min(cfg.Horizon-1, st+rng.Next(5,60)); double d=rng.NextDouble()*0.6-0.3; acts.Add(new ActionStep(v,st,en,d)); }
            outp.Add(new Template($"TPL-{i:00000}", acts));
        }
        return outp;
    }
}

public sealed class Vplc {
    public ExecResult Run(IReadOnlyList<Point> baseline, Template tpl, IReadOnlyList<Constraint> cs, Config cfg){
        var vio=new List<Violation>(); if(baseline.Count==0) return new ExecResult(tpl.Id,new List<Point>(),vio);
        var cur=new Dictionary<string,double>(baseline[0].V); var trace=new List<Point>();
        for(int t=0;t<cfg.Horizon;t+=cfg.Step){
            if(t<baseline.Count) foreach(var kv in baseline[t].V) cur[kv.Key]=kv.Value;
            foreach(var a in tpl.Actions.Where(a=>t>=a.Start && t<=a.End)) if(cur.ContainsKey(a.Variable)) cur[a.Variable]+=a.DeltaPerSec*cfg.Step;
            foreach(var k in cur.Keys.ToList()) cur[k]=Math.Max(-1e6,Math.Min(1e6,cur[k]*0.9995));
            Alarm alarm=Alarm.None;
            foreach(var c in cs){
                if(!cur.TryGetValue(c.Variable,out var v)) continue;
                if(c.Max is double mx && v>mx){ vio.Add(new Violation(c.Id,t,c.Variable,v,"UpperBound")); alarm=c.Layer==Layer.Safety?Alarm.Trip:Alarm.Alarm; }
                if(c.Min is double mn && v<mn){ vio.Add(new Violation(c.Id,t,c.Variable,v,"LowerBound")); alarm=c.Layer==Layer.Safety?Alarm.Trip:Alarm.Alarm; }
            }
            trace.Add(new Point(t,new Dictionary<string,double>(cur),alarm));
            if(alarm==Alarm.Trip) break;
        }
        return new ExecResult(tpl.Id,trace,vio);
    }
}

public sealed class Recovery {
    public DecisionResult Classify(ExecResult r, IReadOnlyList<Constraint> cs, IReadOnlyList<OperatorRule> rules){
        var rv=rules.Select(x=>x.Variable).ToHashSet();
        foreach(var v in r.Violations.OrderBy(x=>x.T)){
            var c=cs.FirstOrDefault(x=>x.Id==v.ConstraintId); if(c is null) continue;
            if(c.Layer==Layer.Safety) return new DecisionResult(r.TemplateId, Decision.RecoveryUnsafe, "Safety-layer violation", v.T);
            if(rv.Contains(c.Variable)) return new DecisionResult(r.TemplateId, Decision.RecoveryInfeasible, "Recovery variable violated", v.T);
        }
        return new DecisionResult(r.TemplateId, Decision.RecoverySafe, "No recovery-critical violations", -1);
    }
}

public sealed class Runner {
    public string Run(string outDir, string plc, string esd, string op, string traceCsv){
        Directory.CreateDirectory(outDir);
        var cfg=new Config(600,1,20,140,2026);
        var ex=new StaticExtractor(); var tr=new TraceEngine(); var gen=new Generator(); var sim=new Vplc(); var rec=new Recovery();
        var constraints=ex.Extract(plc,esd,op);
        var baseline=tr.LoadCsv(traceCsv);
        var windows=tr.Partition(baseline,cfg.Segment);
        var slack=tr.Slack(windows,constraints);
        var patterns=tr.Patterns(constraints,slack);
        var templates=gen.Generate(constraints,cfg);
        var rules = constraints.Where(c=>c.Layer==Layer.Operator && c.Max is not null).Select(c=>new OperatorRule(c.Variable,c.Max!.Value,30)).ToList();

        var exec = new List<ExecResult>();
        var cls = new List<DecisionResult>();
        foreach(var t in templates){
            var er=sim.Run(baseline,t,constraints,cfg);
            exec.Add(er);
            cls.Add(rec.Classify(er,constraints,rules));
        }

        File.WriteAllText(Path.Combine(outDir,"constraints.json"), JsonSerializer.Serialize(constraints, Io.J));
        File.WriteAllText(Path.Combine(outDir,"patterns.json"), JsonSerializer.Serialize(patterns, Io.J));
        File.WriteAllText(Path.Combine(outDir,"templates.json"), JsonSerializer.Serialize(templates, Io.J));
        File.WriteAllText(Path.Combine(outDir,"classification.json"), JsonSerializer.Serialize(cls, Io.J));
        var summary = new {
            total=cls.Count,
            safe=cls.Count(x=>x.Decision==Decision.RecoverySafe),
            infeasible=cls.Count(x=>x.Decision==Decision.RecoveryInfeasible),
            unsafeCount=cls.Count(x=>x.Decision==Decision.RecoveryUnsafe)
        };
        File.WriteAllText(Path.Combine(outDir,"summary.json"), JsonSerializer.Serialize(summary, Io.J));
        return outDir;
    }
}
