using BLINDSPOT.Engine;
using Xunit;

public class PipelineTests
{
    [Fact]
    public void Runner_ProducesSummary()
    {
        var outDir = Path.Combine(Path.GetTempPath(), "blindspot_test_" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(outDir);
        var datasets = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "../../../../datasets"));
        var r = new Runner();
        var p = r.Run(outDir,
            Path.Combine(datasets, "plc_program.json"),
            Path.Combine(datasets, "esd_program.json"),
            Path.Combine(datasets, "operator_rules.json"),
            Path.Combine(datasets, "trace.csv"));
        Assert.True(File.Exists(Path.Combine(p, "summary.json")));
    }
}
