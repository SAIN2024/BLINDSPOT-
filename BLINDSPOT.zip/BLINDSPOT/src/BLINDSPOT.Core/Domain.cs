namespace BLINDSPOT.Core;
public enum Layer { Control, Operator, Safety }
public enum CType { LowerBound, UpperBound, RateLimit }
public enum Decision { RecoverySafe, RecoveryInfeasible, RecoveryUnsafe }
public enum Alarm { None, Alarm, Trip }
public sealed record Constraint(string Id,string Variable,Layer Layer,CType Type,double? Min,double? Max,double? MaxRate);
public sealed record OperatorRule(string Variable,double Target,int WithinSeconds);
public sealed record Point(int T, IReadOnlyDictionary<string,double> V, Alarm A);
public sealed record Window(int Start, int End, IReadOnlyList<Point> Points);
public sealed record Slack(int T,string ConstraintId,double Value);
public sealed record Pattern(string ConstraintId,double MinSlack,double TimeToConstraint,double RecoveryRate);
public sealed record ActionStep(string Variable,int Start,int End,double DeltaPerSec);
public sealed record Template(string Id,IReadOnlyList<ActionStep> Actions);
public sealed record Violation(string ConstraintId,int T,string Variable,double Value,string Reason);
public sealed record ExecResult(string TemplateId,IReadOnlyList<Point> Trace,IReadOnlyList<Violation> Violations);
public sealed record DecisionResult(string TemplateId,Decision Decision,string Reason,int FirstViolation);
public sealed record Config(int Horizon,int Step,int Segment,int MaxTemplates,int Seed);
