using BLINDSPOT.Engine;

static string Arg(string[] a, string k, string d){ var i=Array.IndexOf(a,k); return (i>=0 && i+1<a.Length)?a[i+1]:d; }

var outDir = Arg(args, "--out", "artifacts/run1");
var plc = Arg(args, "--plc", "datasets/plc_program.json");
var esd = Arg(args, "--esd", "datasets/esd_program.json");
var op  = Arg(args, "--operator", "datasets/operator_rules.json");
var trace = Arg(args, "--trace", "datasets/trace.csv");

var runner = new Runner();
var path = runner.Run(outDir, plc, esd, op, trace);
Console.WriteLine("Completed: " + Path.GetFullPath(path));
